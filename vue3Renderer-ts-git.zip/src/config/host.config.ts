export const hostConfig = {
    port: 30000, // 渲染服务端口
    chromePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', // windows浏览器路径
    // chromePath: '/usr/bin/chromium-browser', // linux浏览器路径
}